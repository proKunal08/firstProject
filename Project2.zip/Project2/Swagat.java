package com.kaldin;

import java.io.PrintWriter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mysql.cj.xdevapi.JsonArray;
import com.mysql.cj.xdevapi.JsonValue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.google.gson.JsonObject;
@WebServlet("/Swagat")
public class Swagat extends HttpServlet {
public void doGet(HttpServletRequest request,HttpServletResponse response) {
	String username1=request.getParameter("a");
	String password1=request.getParameter("b");
	Connection con = null;
	
try {
//	JsonObject object=new JsonObject();
	JSONObject jsonObject=new JSONObject();
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
		System.out.println("jdbc connected");
	
		PreparedStatement stmt = con.prepareStatement("SELECT COUNT(*) AS count FROM Sportsheet WHERE Username='"+ username1 + "' AND Password='" + password1 + "'");
		ResultSet rs=stmt.executeQuery();
		 String status ="";
		
		while(rs.next()) {
			if(rs.getInt("count")>0) {
				status= "login";
				
				}else {
				status="Wrong info";
				
			}
			jsonObject.put("value", status);
			response.setContentType("application/json;");
	        PrintWriter writer = response.getWriter();
			writer.write(jsonObject.toString());
			writer.close();
		}con.close();
		
} catch(Exception e) {
	e.printStackTrace();
}
}
}