package com.kaldin;


	import java.io.PrintWriter;
	import com.google.gson.Gson;
	import com.google.gson.JsonObject;
	import com.mysql.cj.xdevapi.JsonArray;
	import com.mysql.cj.xdevapi.JsonValue;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;

	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	import org.json.JSONObject;

	import com.google.gson.Gson;
	import com.google.gson.JsonObject;
	@WebServlet("/Updatedata")
	public class Updatedata extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) {
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String age=request.getParameter("age");
		String sport=request.getParameter("sport");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		Connection con = null;
		try {
//			JSONObject jsonObject=new JSONObject();
			JsonObject obj=new JsonObject();
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
			System.out.println("jdbc connected");
			PreparedStatement ps = con.prepareStatement("UPDATE Sportsheet set Name=?,DOB=?,Age=?,Sport=?,Username=?,Password=? where Id=?");
			ps.setString(1, name);
			ps.setString(2, dob);
			ps.setString(3, age);
			ps.setString(4, sport);
			ps.setString(5, username);
			ps.setString(6, password);
			ps.setString(7,id);
	        int x= ps.executeUpdate();
	        String status ="";
	        if(x==1) {
	        	 status = "sucessfully updated";
	        }else {
	        	status = "not sucessfully updated";
	        }
//	      jsonObject.put("status", status);
	        obj.addProperty("insert", status);
	        response.setContentType("application/json;");
	        PrintWriter writer = response.getWriter();
			writer.write(obj.toString());
			writer.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	}


