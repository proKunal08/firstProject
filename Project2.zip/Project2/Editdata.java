package com.kaldin;

import java.awt.Window;
import java.io.PrintWriter;
import java.sql.Connection;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mysql.cj.Session;
import com.mysql.cj.xdevapi.JsonArray;
import com.mysql.cj.xdevapi.JsonValue;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Editdata")
public class Editdata extends HttpServlet {
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) {
		Connection con = null;
		ArrayList<Person> list=new ArrayList<Person>();
//		JsonObject obj=new JsonObject();
		
		try {
			String Id=request.getParameter("Id");
			System.out.println(Id);			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
			System.out.println("jdbc connected");
			Statement stmt= con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Sportsheet where Id='"+Id+"'");
			Person edt=new Person();
			String stat="";
			if (rs.next()) {
				edt.setId(rs.getString("Id"));
				edt.setName(rs.getString("Name"));
				edt.setDOB(rs.getString("DOB"));
				edt.setAge(rs.getString("Age"));
				edt.setSport(rs.getString("Sport"));
				edt.setUsername(rs.getString("Username"));
				edt.setPassword(rs.getString("Password"));
			}
			con.close();
			request.getSession().setAttribute("edt", edt);
//			RequestDispatcher dispatcher = request.getRequestDispatcher("Editdata.jsp");
//		    dispatcher.forward(request, response);
            response.sendRedirect("Editdata.jsp");
//			obj.addProperty("stat", stat);
//	        response.setContentType("application/json;");
//	        PrintWriter writer = response.getWriter();
//			writer.write("Ok");
//			writer.close();
			
			
			
			
		}catch(Exception e) {
		System.out.println(e);
	}
	}
}

