package com.kaldin;

import java.io.PrintWriter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mysql.cj.xdevapi.JsonArray;
import com.mysql.cj.xdevapi.JsonValue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
@WebServlet("/Registration")
public class Registration extends HttpServlet{
public void doPost(HttpServletRequest request,HttpServletResponse response) {
	String name=request.getParameter("a");
	String dob=request.getParameter("b");
	String age=request.getParameter("c");
	String sport=request.getParameter("d");
	String username=request.getParameter("e");
	String password=request.getParameter("f");
	
	Connection con = null;
	try {
//		JSONObject jsonObject=new JSONObject();
		JsonObject obj=new JsonObject();
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
		System.out.println("jdbc connected");
		PreparedStatement ps = con.prepareStatement("insert into Sportsheet(Name,DOB,Age,Sport,Username,Password)values(?,?,?,?,?,?)");
		ps.setString(1, name);
		ps.setString(2, dob);
		ps.setString(3, age);
		ps.setString(4, sport);
		ps.setString(5, username);
		ps.setString(6, password);
        int x= ps.executeUpdate();
        String status ="";
        if(x==1) {
        	 status = "successfully register";
        }else {
        	status = "not successfully register";
        }
//      jsonObject.put("status", status);
        obj.addProperty("update", status);
        response.setContentType("application/json;");
        PrintWriter writer = response.getWriter();
		writer.write(obj.toString());
		writer.close();
		con.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
}

