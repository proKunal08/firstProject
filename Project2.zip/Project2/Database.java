package com.kaldin;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Database")
public class Database extends HttpServlet {
public void doGet(HttpServletRequest request,HttpServletResponse response) {
	Connection con =null;
	ArrayList<Person> list=new ArrayList<Person>();
	
	try {
	Class.forName("com.mysql.jdbc.Driver");
	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
	System.out.println("jdbc connected");
	Statement stmt =con.createStatement();
	ResultSet rs = stmt.executeQuery("select * from Sportsheet");
	PrintWriter out=response.getWriter();
	 
	while(rs.next()) {
		Person person=new Person();
		person.setId(rs.getString("id"));
		person.setName(rs.getString("Name"));
		person.setDOB(rs.getString("DOB"));
		person.setAge(rs.getString("Age"));
		person.setSport(rs.getString("Sport"));
		person.setUsername(rs.getString("Username"));
		person.setPassword(rs.getString("Password"));
		list.add(person);
	}con.close();
	      request.setAttribute("list", list);
	      request.getRequestDispatcher("/Database.jsp").forward(request,response);
//	      response.sendRedirect("/Database.jsp");
	
	
	
}catch(Exception e) {
	System.out.println(e);
}
}


}

