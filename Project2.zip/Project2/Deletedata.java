package com.kaldin;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
@WebServlet("/Deletedata")

public class Deletedata extends HttpServlet {
public void doPost(HttpServletRequest request,HttpServletResponse response) {
		try {
			JSONObject jsonObject=new JSONObject();
			String Id=request.getParameter("Id");
			Connection con = null;
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kunaldb", "root", "Kaldin1234!");
			System.out.println("jdbc connected");
			PreparedStatement ps = con.prepareStatement("DELETE FROM Sportsheet WHERE Id='"+Id+"'");
			int x=ps.executeUpdate();
			System.out.println(x);
			String delet = "";
			if(x==1) {
				delet="delete successfully";
			}else{
				delet="delete unsuccessfully";
			}
			 
			 jsonObject.put("delet", delet);
		        response.setContentType("application/json; charset=UTF-8");
		        PrintWriter writer = response.getWriter();
				writer.write(jsonObject.toString());
				writer.close();
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
		}
	}
	}
